from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import UnauthorizedError
from app.core.security import (
    create_access_token,
    create_refresh_token,
    verify_password,
)
from app.modules.users.repository import UserRepository


class AuthService:
    def __init__(self) -> None:
        self.user_repo = UserRepository()

    async def login(self, db: AsyncSession, *, email: str, password: str) -> dict:
        user = await self.user_repo.get_by_email(db, email)
        if not user or not verify_password(password, user.password_hash):
            raise UnauthorizedError("Invalid email or password")

        if not user.is_active:
            raise UnauthorizedError("User is inactive")

        return {
            "access_token": create_access_token(str(user.id)),
            "refresh_token": create_refresh_token(str(user.id)),
            "token_type": "bearer",
        }