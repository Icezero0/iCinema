from pydantic import BaseModel, ConfigDict, EmailStr, Field


class UserCreate(BaseModel):
    email: EmailStr
    username: str | None = Field(default=None, max_length=64)
    password: str = Field(min_length=6)


class UserPatch(BaseModel):
    username: str | None = Field(default=None, max_length=64)
    password: str | None = Field(default=None, min_length=6)
    auto_accept: bool | None = None

class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    email: EmailStr
    username: str | None
    avatar_path: str | None
    auto_accept: bool
    is_active: bool


class UserMeResponse(UserResponse):
    pass


class AvatarUploadResponse(BaseModel):
    avatar_path: str